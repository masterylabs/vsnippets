<?php

// requires vue module
add_action( 'admin_menu', function() use($app, $options) {
  new Vsnippets_WpAdminPage($app, $options);
});


// admin page