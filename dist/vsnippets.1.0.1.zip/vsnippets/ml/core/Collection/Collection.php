<?php

abstract class Vsnippets_Collection
{
    use
    Vsnippets_Collection_Index,
    Vsnippets_Collection_Create,
    Vsnippets_Collection_Destroy,
    Vsnippets_Collection_Events,
    Vsnippets_Collection_Getters,
    Vsnippets_Collection_Headers,
    Vsnippets_Collection_ListView,
    Vsnippets_Collection_Model,
    // Vsnippets_Collection_Order,
    Vsnippets_Collection_Parsers,
    Vsnippets_Collection_Show,
    Vsnippets_Collection_Slug,
    // Vsnippets_Collection_Unique,
        Vsnippets_Collection_Update;

    protected $can_create = false;

    protected $can_edit = false;

    protected $can_delete = false;

    protected $can_dublicate = false;

    protected $no_permissions = false;

    protected $no_headers = false;

    protected $no_pagin = false;

    protected $use_slug = false;

    protected $fills;

    protected $hidden;

    protected $timestamps;

    protected $cols = ['*'];

    protected $show_append;

    protected $query_method;

    private $association;

    private $id;

    public function __call($name, $re)
    {
        if (method_exists($this, $name)) {
            if (!in_array($name, ['index', 'create'], true)) {
                $this->id = $re[0]->id;
            }
            return;
        }
       
        preg_match_all('/((?:^|[A-Z])[a-z]+)/', $name, $words);

        $words = $words[0];

        // Inversion Method Name

        $method = ucFirst($words[0]);
        $type = strtolower(end($words));
        if ($type === 'index') {
            $method = 'list' . $method;
        } else {
            $method = $type . Vsnippets_Inflector::singularize($method);
        }

        if (method_exists($this, $method)) {

            // no list, convert to singular
            if (!in_array($type, ['index', 'create'], true)) {
                $this->id = $re[0]->id;
                // add singular to request
                $itemKey = $words[0];
                $itemValue = $re[0]->{$itemKey};

                unset($re[0]->{$itemKey});

                $itemKey = Vsnippets_Inflector::singularize($itemKey);
                $re[0]->{$itemKey} = $itemValue;
            }

            return $this->{$method}($re[0], $re[1]);
        }

        // Doesn't exist

        // $req = $re[0];

        $method = strtolower(array_pop($words));
        $sub = lcfirst(implode('', $words));

        $this->association = lcfirst(implode('', $words));

        // non index will have it

        if (!in_array($method, ['index', 'create'], true)) {
      
            $this->id = $re[0]->{$this->association};
        }

        // required to skip custom primary methods
        if (isset($this->association)) {
            $method = '_' . ucfirst($method);
        }

        return $this->{$method}($re[0], $re[1]);
    }
}
