<?php

trait Vsnippets_Model_QueryBeforeRequest
{
  // public function onColsBeforeRequest($cols)
  // {
  //   // foreach($cols as $key => $value) {
  //   //   if(in_array($this->upgrade_page_id))
  //   //   // ee($key, $value);
  //   // }

  //   // ee('cols', $cols);
  //   return $cols;
  // }
}