<?php

trait Vsnippets_Model_BeforeCreate
{
    // decomment to use in model

    // public function beforeCreate()
    // {
    //     // $this->identifier = 'abc';
    // }
}
