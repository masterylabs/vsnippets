<?php

// if (class_exists('Vsnippets_App')) {
//     return;
// }

class Vsnippets_App
{
    use Vsnippets_NameToFile,
        Vsnippets_MakeKey,

    // Router Traits
    Vsnippets_App_Router_Api,
    Vsnippets_App_Router_Calls,
    Vsnippets_App_Router_Collection,
    Vsnippets_App_Router_Events,
    Vsnippets_App_Router_Group,
    Vsnippets_App_Router_Methods,
    Vsnippets_App_Router_Middleware,
    Vsnippets_App_Router_Name,
    Vsnippets_App_Router_Namespace,
    Vsnippets_App_Router_Validations,
    Vsnippets_App_Router_IgnoreRoutes,

    // Traits
    Vsnippets_App_Create,
    Vsnippets_App_Db,
    Vsnippets_App_Fs,
    Vsnippets_App_Getters,
    Vsnippets_App_Host,
    Vsnippets_App_License,
    Vsnippets_App_Loaders,
    Vsnippets_App_Meta,
    Vsnippets_App_Migrate,
    Vsnippets_App_Module,
    Vsnippets_App_Run,
    Vsnippets_App_Remote,
    Vsnippets_App_Settings;

    public $app_id;

    public $app_url;

    public $site_url;

    public $request_method;

    public $app_prefix = 'Vsnippets_';

    public $base_route;

    public $api_route;

    private $mailer; // not sure whats going on here

    private $route_atts = [];

    private $route_names = [];
    


    /**
     * Router
     */
    private $is_api_route = false;

    private $is_valid_route = false;

    private $is_valid_module_route = false;

    // private $is_valid_api = false;

    private $valid_route_middleware = [];

    private $valid_route_cb;


    /**
     * NEW VERSION
     */

    /**
     * Public
     */

    public $version = '0.0.1';

    protected $db_table_prefix = '';

    /**
     * Private
     */

    private $_config;

    private $_host;

    private $_db; // made private

    private $_info;
    
    private $_cors_allowed = false;

    private $_class_prefix = 'Vsnippets_';

    public function getProp($key, $def = null)
    {
        return isset($this->{$key}) ? $this->{$key} : $def;
    }


    public static function env($key, $def = '')
    {
        return isset(self::$_env) && !empty(self::$_env[$key]) ? self::$_env[$key] : $def;
    }
}
