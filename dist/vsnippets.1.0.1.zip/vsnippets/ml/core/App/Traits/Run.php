<?php

trait Vsnippets_App_Run
{

    public function run($cb = false, $args = null)
    {
        global $vsnippets_app;

        $vsnippets_app = $this;
        
        if($cb) {
            $this->onValidRoute($cb, $args);
            return $this->callRoute();
        }

        if ($this->is_valid_route) {
            $this->callRoute();
        }
    }
}
