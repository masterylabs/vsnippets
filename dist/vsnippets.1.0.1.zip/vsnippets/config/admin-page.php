<?php

return [
  'vue' => 'client/index', 
  'auth' => 'user-auth', 
  'use_wp_media' => true, 
  'icon_url' => VSNIPPETS_PUBLIC_URL.'/img/dashicon.png'
];