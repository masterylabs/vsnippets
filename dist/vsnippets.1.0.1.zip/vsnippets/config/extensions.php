<?php

return [
    [
      'name' => 'vsnippets-quick-links',
      'routes' => 'web' // string, boolean, array
    ]
  ];
