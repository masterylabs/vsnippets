<?php

return [
    'table_prefix' => true,
];