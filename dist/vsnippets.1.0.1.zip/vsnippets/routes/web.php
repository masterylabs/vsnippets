<?php
$app->get('embed/{video}', 'VideoController@embed');