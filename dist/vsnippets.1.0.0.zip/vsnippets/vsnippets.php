<?php
/*
Plugin Name: vSnippets
Description: Video embed only the part you want!
Version: 1.0.0
Author: Matthew McDonald
Plugin URI: https://vsnippets.com
Author URI: https://masterylabs.com
 */

if (!defined('ABSPATH')) exit;

if(!defined('VSNIPPETS_WP_PLUGIN_FILE')) define('VSNIPPETS_WP_PLUGIN_FILE', __FILE__);

require_once __DIR__ . '/bootstrap/wp.php';