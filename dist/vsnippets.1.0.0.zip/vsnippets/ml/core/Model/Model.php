<?php


class Vsnippets_Model
{
    use Vsnippets_MakeKey, 
    Vsnippets_Model_Attach,
    Vsnippets_Model_BelongsTo,
    Vsnippets_Model_BelongsToMany,
    Vsnippets_Model_HasMany,
    Vsnippets_Model_HasOne,
    Vsnippets_Model_PivotOrder,
    // Vsnippets_Model_BeforeCreate,
    Vsnippets_Model_QueryError,
    Vsnippets_Model_All,
    Vsnippets_Model_Count,
    Vsnippets_Model_Create,
    Vsnippets_Model_Destroy,
    Vsnippets_Model_Filters,
    Vsnippets_Model_Find,
    Vsnippets_Model_FindOrCreate,
    Vsnippets_Model_CreateOrUpdate,
    Vsnippets_Model_First,
    Vsnippets_Model_GetUnique,
    Vsnippets_Model_ItemFormat,
    Vsnippets_Model_LeftJoin,
    Vsnippets_Model_Paginate,
    Vsnippets_Model_Req,
    Vsnippets_Model_Save,
    Vsnippets_Model_Search,
    Vsnippets_Model_Update,
    Vsnippets_Model_Where,

    // query
    // Vsnippets_Model_QueryBeforeRequest,
    Vsnippets_Model_QueryBuilders,
    Vsnippets_Model_QueryCol,
    Vsnippets_Model_QueryCollection,
    Vsnippets_Model_QueryCount,
    Vsnippets_Model_QueryCreate,
    Vsnippets_Model_QueryDelete,
    Vsnippets_Model_QueryRow,
    Vsnippets_Model_QueryUnique,
    Vsnippets_Model_QueryUpdate,
    Vsnippets_Model_QueryWith,

    Vsnippets_Model_Adders,
    Vsnippets_Model_Getters,
    Vsnippets_Model_Helpers,
    Vsnippets_Model_Setters;   
    

    /**
     * Editables
     */

    protected $table;

    protected $cols;

    protected $fills = [];

    protected $headers = [];

    protected $hidden = [];

    protected $bool_cols = [];

    protected $int_cols = []; // 'id'

    protected $search_cols = ['name'];

    protected $default_cols;

    protected $error;

    protected $timestamps = true;

    /**
     * Options
     */

    protected $primary_key = 'id';

    protected $identifier_prefix;

    protected $pivot_timestamps = true;

    protected $query_page = 1;

    protected $query_limit = 0;

    protected $query_limit_max = 1000;

    protected $query_allow_ids_list = true;

    /**
     * Programmables
     */

    // protected static $_app_id;

    protected $table_prefix;

    private $app_prefix; // set in contructor

    private $custom_db;

    private $db_table;

    private $query_row = false;

    private $query_collection = false;

    private $query_cols = [];

    private $query_wheres = [];

    private $query_update_cols = [];

    private $inner_joins = [];

    private $left_joins = [];

    private $query_paginate;

    private $query_paginate_default_limit = 25;

    private $query_offset = 0;

    protected $query_order = ['id', 'ASC'];

    protected $json_cols = [];

    protected $query_children = true;

    // private $query_column_offset = 0;

    // private $query_row_offset = 0;

    private $query_output_type = 'OBJECT'; // ARRAY_A, ARRAY_N

    private $db_row_values; // stored object

    private $hidden_id;

    private $pivot_table;

    private $foreign_key;

    private $foreign_value;

    private $local_key;

    private $_last_query;

    private $query_filters = ['product', 'addon', 'tag'];

    private $query_not_in = []; // must not include filter

    private $query_in = []; // must include id

    private $query_filter_match_any = false;

    private $query_get_unique_max_count = 100;

    private $query_has_many;

    private $query_belongs_to; // not being used yet

    private $query_belongs_to_many;

    private $query_has_one;

    private $query_is_row = false;

    private $query_is_collection = false;

    protected $associations_type;

    protected $query_association_id; // could be private

    // protected $query_association;
    // private $foreign_id;

    protected $was_created = false;

    // added 
    protected $_timestamps_format = 'mysql';

    protected $database;

    private $_database;

    // added 11.2.21
    
    protected $unique_cols; // []
    
    // protected $use_schedule_automator = false;

    // protected $check_unique_cols_on_create = false;

    // protected $check_unique_cols_on_update = false;


    public function __construct()
    {
        global $vsnippets_app;

        if(isset($this->database)) {
            $this->_database = $vsnippets_app->selectDatabse($this->database);
        }
        
        // app_id is added in setup (bootsrap)
        elseif (!isset($this->table_prefix)) {
            $this->table_prefix = Vsnippets_App::getTablePrefix();
        }



        // set cols

        if (!empty($this->cols)) {
            foreach ($this->cols as $key => $value) {

                // set fills (could be default)

                if (isset($value['fillable'])) {
                    array_push($this->fills, $key);
                }

                // headers

                if (isset($value['header'])) {
                    array_push($this->headers, [
                        'text' => isset($value['text']) ? $value['text'] : $key,
                        'value' => $this->keyToText($key),
                    ]);
                }

                if (isset($value['hidden'])) {
                    array_push($this->hidden, $key);
                }

                if (isset($value['bool'])) {
                    array_push($this->bool_cols, $key);
                }

                if (isset($value['int'])) {
                    array_push($this->int_cols, $key);
                }
            }
        }

        // set db_table

        $this->db_table = $this->getTable();
    }


    public function getTable($table = null, $customPrefix = false)
    {

        if (!$table) {
            $table = $this->table;
        }

        if($customPrefix) return $customPrefix . $table;

        if(!empty($this->table_prefix)) return $this->table_prefix . $table;

        return $table;
    }


    public function getProp($key)
    {
        return $this->{$key};
    }


    public function setProp($key, $value)
    {
        $this->{$key} = $value;
    }

    // temp

    private function db()
    {
        if(isset($this->_database)) return $this->_database;
        
        global $wpdb;

        if (!empty($wpdb)) {
            return $wpdb;
        }
       
        return $app->db();
    }


    // public function with($associations, $args = null)
    // {
    // }

    public function __call($name, $args = [])
    {
        // echo $name."\n";
        if (method_exists($this, $name)) {
            return;
        }

        preg_match_all('/((?:^|[A-Z])[a-z]+)/', $name, $w);
        $w = $w[0];

        $key = 'query_' . array_shift($w);

        if(empty($w)) return;

        $w[0] = lcfirst($w[0]);

        $value = implode('', $w);

        if (!isset($this->{$key})) {
            $this->{$key} = [];
        }

        $entry = [$value, $args];

        array_push($this->{$key}, $entry);

        // ee($entry, $args);

        return $this;
    }

    private $query_with;


    public function defaultValues($values = [])
    {
        // return null
        if(empty($this)) {
            return $this;
        }

        foreach($values as $key => $val) {
            if(!isset($this->{$key})) {
                $this->{$key} = $val;
            }
        }

        return $this;
    }

    public function loadFills()
    {
        foreach($this->fills as $i) {
            
            if(!isset($this->{$i})) 
            $this->{$i} = in_array($i, $this->bool_cols) ? false : (in_array($i, $this->int_cols) ? 0 : '');
            
        }

        return $this;
    }
}
