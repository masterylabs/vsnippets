<?php


abstract class Vsnippets_Controller
{
    use Vsnippets_SetGetConfig;
}
