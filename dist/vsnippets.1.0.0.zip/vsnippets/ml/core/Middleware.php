<?php

if (class_exists('Vsnippets_Middleware')) {
    return;
}

abstract class Vsnippets_Middleware
{
    use Vsnippets_SetGetConfig;
}
