<?php

trait Vsnippets_App_Fs
{
  public function fs($name = '') {
    return new Vsnippets_FileSystem($this->app_id, $name);
  }
}
