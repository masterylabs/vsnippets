<?php

trait Vsnippets_App_Remote
{
    private $_remote;

    public function remote($forceNew = false)
    {
        if ($forceNew || !isset($this->_remote)) {
            $this->_remote = new Vsnippets_Remote();
        }
    
        return $this->_remote;
    }
}
