<?php

trait Vsnippets_App_Db
{
    private $_databases = [];

    public function selectDatabse($name) {

        if(!isset($this->_databases[$name])) {
            $this->_databases[$name] = new Vsnippets_Db($this->_config['db'][$name]);
        }

        return $this->_databases[$name];
    }

    public function db()
    {
        if (isset($this->_db)) {
            return $this->_db;
        }

        if (VSNIPPETS_IS_WP) {
            global $wpdb;
            $this->_db = $wpdb;
        } elseif (!empty($this->_config['db'])) {
            $this->_db = new Vsnippets_Db($this->_config['db']);
        }

        return $this->_db;
    }
}
