<?php

trait Vsnippets_App_Migrate
{
  private $_migration;


  public function migrate() 
  {
    // $m = new Vsnippets_Migration($this);

    Vsnippets_Migration::createOrUpdateDir(VSNIPPETS_MIGRATIONS_PATH, $this);

    if(!empty($this->modules)) {
      foreach($this->modules as $mod) {
        $dir = $mod['path'].'migrations';
        
        if(file_exists($dir))
        Vsnippets_Migration::createOrUpdateDir($dir, $this);
      }
    }

  }
}