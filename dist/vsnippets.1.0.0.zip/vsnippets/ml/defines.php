<?php

// version 2 always defined

define('VSNIPPETS_IS_WP', defined('VSNIPPETS_WP_PLUGIN_FILE'));

if(!defined('VSNIPPETS_PATH')) 
define('VSNIPPETS_PATH', __DIR__.'/');

if(!defined('VSNIPPETS_APP_PATH'))
define('VSNIPPETS_APP_PATH', substr(VSNIPPETS_PATH, 0, -3));

if(!defined('VSNIPPETS_CONFIG_PATH'))
define('VSNIPPETS_CONFIG_PATH', VSNIPPETS_APP_PATH . 'config/');

if(!defined('VSNIPPETS_MIGRATIONS_PATH'))
define('VSNIPPETS_MIGRATIONS_PATH', VSNIPPETS_APP_PATH . 'db/migrations/');

// used for non-wp file system
if(!defined('VSNIPPETS_UPLOADS_PATH'))
define('VSNIPPETS_UPLOADS_PATH', VSNIPPETS_PATH . '../');


/**
 * Structure change options
 */

if(!defined('VSNIPPETS_MODULES_PATH'))
define('VSNIPPETS_MODULES_PATH', VSNIPPETS_PATH . 'modules/');


// module migrations is always modules path/migrations

// eg. VSNIPPETS_CONTROLLERS_PATH

foreach(['Collections', 'Controllers', 'Middleware', 'Models'] as $i) {
  $d = 'VSNIPPETS_'.strtoupper($i).'_PATH';  
  if(!defined($d)) 
  define($d, VSNIPPETS_APP_PATH . 'app/'.$i.'/');
}

