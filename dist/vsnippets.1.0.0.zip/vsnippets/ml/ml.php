<?php

/**
 * ML Version: 0.0.3
 */


// required before helpers

require __DIR__ . '/defines.php';

require __DIR__ . '/helpers/helpers.php';

// define app
$vsnippets_app;

/**
 * Conditional Defines
 */

if(!defined('VSNIPPETS_PUBLIC_URL')) {
  if(VSNIPPETS_IS_WP) define('VSNIPPETS_PUBLIC_URL', plugin_dir_url(__DIR__).'public');
  else define('VSNIPPETS_PUBLIC_URL', vsnippets_get_site_url());
}

if(!defined('VSNIPPETS_PUBLIC_PATH')) define('VSNIPPETS_PUBLIC_PATH', VSNIPPETS_APP_PATH . 'public/');

if(!defined('VSNIPPETS_SITE_URL')) {
  if(VSNIPPETS_IS_WP) define('VSNIPPETS_SITE_URL', get_site_url());
  else define('VSNIPPETS_SITE_URL', vsnippets_get_site_url());
}


// Load Core
vsnippets_autoload(VSNIPPETS_PATH . 'core');

// Load Models 
if(file_exists(VSNIPPETS_MODELS_PATH)) vsnippets_autoload(VSNIPPETS_MODELS_PATH);
