<?php
class Vsnippets_BrandMiddleware extends Vsnippets_Middleware
{
  public function handle($req, $res)
  {
    $app = $req->getApp();

    $req->brand = Vsnippets_Brand::get($app);

    // ee($req);
    return $req;
  }
}