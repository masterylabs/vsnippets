<?php

/**
 * Receiving $app and $options
 * $options can be set in bootsrap, or as a config option
 */

// add any includes
