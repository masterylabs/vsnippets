<?php
return;

class Vsnippets_SampleModuleMiddleware extends Vsnippets_Middleware
{
  public function handle($req, $res) {
    // validate

    return $req;
  }
}