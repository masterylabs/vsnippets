<?php


// class Vsnippets_Client
// {

// }

require __DIR__ . '/routes.php';