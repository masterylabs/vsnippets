<?php
return;

class Vsnippets_SampleMiddleware extends Vsnippets_Middleware
{
  public function handle($req, $res) {
    // validate

    return $req;
  }
}