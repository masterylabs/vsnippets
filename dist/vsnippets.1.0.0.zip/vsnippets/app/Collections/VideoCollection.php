<?php

class Vsnippets_VideoCollection extends Vsnippets_Collection
{
  // protected $no_permissions = true;

  // protected $no_headers = true;

  protected function getModel()
  {
      return new Vsnippets_Video;
  }
}