<?php
class Vsnippets_PlayerBrandingController
{

  public function index($req, $res)
  {
    $value = new Vsnippets_PlayerBranding(true);
    return $res->data($value);
  }

  public function update($req, $res)
  {
    Vsnippets_PlayerBranding::update($req->jsonData);
    return $res->success('Updated');
  }

 
}