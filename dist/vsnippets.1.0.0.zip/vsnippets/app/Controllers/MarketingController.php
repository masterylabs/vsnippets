<?php


class Vsnippets_MarketingController
{
  public function updatePauseBanner($req, $res) 
  {
    Vsnippets_PauseBanner::update($req);
    return $res->success();
  }


  public function updatePromoAlert($req, $res) 
  {
    Vsnippets_PromoAlert::update($req);
    return $res->success();
  }


  public function updateEndPoster($req, $res) 
  {
    Vsnippets_EndPoster::update($req);
    return $res->success();
  }

}