<?php

return [
    'is_debug' => false,
    'is_dev' => false,
    'app_id' => 'mlvs221',
    'app_name' => 'vSnippets',
    'app_dbv' => 1.0,
    'app_host' => 'https://api-v2.masterylabs.com/apps',
    'content_host' => 'https://api-v2-content.masterylabs.com',
    'url_prefix' => 'vsnippets',
    'admin_capability' => 'administrator',
    'key_name' => '',
    'shortcode_key' => 'vsnippets'
];